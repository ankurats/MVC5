﻿using HelloWorldApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HelloWorldApp.Controllers
{
    public class RestaurantController : Controller
    {
        RestaurantRepo _repo = new RestaurantRepo();
        // GET: Restaurant

    [ActionName("Index")]
        public ActionResult fun()
        {
            var res = _repo.GetRestaurant();
            return View(res);
        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            var res = _repo.GetById(id);
            return View(res);
        }

        [HttpPost]
        public ActionResult Edit(int id, Restaurant rest)
        {
            if (ModelState.IsValid)
            {
                _repo.EditRestaurant(id, rest);
                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            var res = _repo.GetById(id);
            return View(res);
        }

        [HttpPost]
        public ActionResult Delete(int id, Restaurant rest)
        {
            if (ModelState.IsValid)
            {
                _repo.RemoveById(id);
                return RedirectToAction("Index");
            }
            return View();
        }


        [HttpGet]
        public ActionResult Create()
        {

            return View();
        }
        [HttpPost]
        public ActionResult Create(FormCollection flc)
        {
            Restaurant rest = new Restaurant
            {
                Title = flc["name"],
                City = flc["City"],
                Rating = Convert.ToInt32(flc["Rating"])
            };
            if (rest != null)
            {
                _repo.AddRestaurant(rest);
                return RedirectToAction("Index");
            }
            return View();
        }
    }
}