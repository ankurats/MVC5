﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HelloWorldApp.Controllers
{
   
    public class DefaultController : Controller
    {
        // GET: Default
        public ActionResult Index()
        {
            //ViewData["id"] = "Hello from view data ";
            TempData["name"] = "Rahul"; 
            ViewBag.id = "Hello from view Bag ";
             return RedirectToAction("Fun");
          //  return View();
        }
        public ActionResult Fun()
        {
           
            return View();
        }
    }
}