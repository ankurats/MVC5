﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HelloWorldApp.Models
{
    public class RestaurantRepo
    {
        static List<Restaurant> list = new List<Restaurant>()
        {
            new Restaurant {Id =1, Title="Mogli", City="Noida", Rating=5 },
            new Restaurant {Id =2, Title="Bhaiji", City="gurugram", Rating=4 },
            new Restaurant {Id =3, Title="YoChina", City="Noida", Rating=5 },
            new Restaurant {Id =4, Title="Sherkhan", City="Delhi", Rating=4 }
        };

        public IEnumerable<Restaurant> GetRestaurant()
        {
            return list;
        }

        public Restaurant GetById(int id)
        {
            return list.Find(x => x.Id == id);
        }

        public void AddRestaurant(Restaurant rest)
        {
            var maxId = list.Max(x => x.Id);
            rest.Id = maxId + 1;
            list.Add(rest);
        }

        public void EditRestaurant(int id, Restaurant rest)
        {
            var res = GetById(id);
            if(res != null)
            {
                res.Title = rest.Title;
                res.Rating = rest.Rating;
                res.City = rest.City;
            }
        }

        public void RemoveById(int id)
        {
            var res = GetById(id);
            if(res != null)
            {
                list.Remove(res);
            }
        }
    }
}